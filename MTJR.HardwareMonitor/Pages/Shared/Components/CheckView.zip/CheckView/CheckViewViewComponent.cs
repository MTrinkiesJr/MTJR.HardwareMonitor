using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MTJR.HealthMonitor.Model;
using MTJR.HealthMonitor.Pages.Shared.Components.ListView;

namespace MTJR.HealthMonitor.Pages.Shared.Components.CheckView
{
    public class CheckViewViewComponent : ViewComponent
    {
        private HealthCheckCollection _healthCheckCollection;

        public CheckViewViewComponent(HealthCheckCollection healthCheckCollection)
        {
            _healthCheckCollection = healthCheckCollection;
        }

        public async Task<IViewComponentResult> InvokeAsync(string id)
        {
            return View("Default", new CheckViewViewComponentModel(_healthCheckCollection, id.Split("tr_")[1]));
        }
    }
}
