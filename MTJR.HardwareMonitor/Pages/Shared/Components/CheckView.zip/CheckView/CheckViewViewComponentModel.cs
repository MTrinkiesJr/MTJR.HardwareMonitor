﻿using System.Linq;
using MTJR.HealthMonitor.Model;

namespace MTJR.HealthMonitor.Pages.Shared.Components.CheckView
{
    public class CheckViewViewComponentModel
    {
        public HealthCheck HealthCheck { get; set; }
        public bool Creating { get; set; }

        public CheckViewViewComponentModel(HealthCheckCollection healthChecks, string id)
        {
            if (id == "create")
            {
                Creating = true;
                HealthCheck = new HealthCheck();
            }
            else
            {
                HealthCheck = healthChecks.FirstOrDefault(a => a.Id == id);
            }
        }
    }
}
